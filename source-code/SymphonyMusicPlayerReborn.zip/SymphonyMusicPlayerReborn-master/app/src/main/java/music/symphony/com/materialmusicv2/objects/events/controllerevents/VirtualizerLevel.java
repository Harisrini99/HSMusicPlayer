package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class VirtualizerLevel {

    public int level;

    public VirtualizerLevel(int level) {
        this.level = level;
    }
}
