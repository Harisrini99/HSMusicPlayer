package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class RemoveFromQueue {
    public int position;

    public RemoveFromQueue(int position) {
        this.position = position;
    }
}
