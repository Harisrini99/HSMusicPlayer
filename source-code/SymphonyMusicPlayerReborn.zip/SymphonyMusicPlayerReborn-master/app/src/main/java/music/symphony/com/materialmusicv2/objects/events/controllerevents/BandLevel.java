package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class BandLevel {
    public short band;
    public short level;

    public BandLevel(short band, short level) {
        this.band = band;
        this.level = level;
    }
}
