package music.symphony.com.materialmusicv2.objects.events;

public class PlaybackState {
    public boolean state;

    public PlaybackState(boolean state) {
        this.state = state;
    }
}
