package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class EquallizerEnabled {

    public boolean enabled;

    public EquallizerEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
