package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class VisualizerTypeChanged {
    public int visualizerType;

    public VisualizerTypeChanged(int visualizerType) {
        this.visualizerType = visualizerType;
    }
}
