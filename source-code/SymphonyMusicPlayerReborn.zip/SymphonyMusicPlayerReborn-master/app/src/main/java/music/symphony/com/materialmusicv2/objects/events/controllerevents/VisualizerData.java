package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class VisualizerData {

    public byte[] data;

    public VisualizerData(byte[] data) {
        this.data = data;
    }
}
