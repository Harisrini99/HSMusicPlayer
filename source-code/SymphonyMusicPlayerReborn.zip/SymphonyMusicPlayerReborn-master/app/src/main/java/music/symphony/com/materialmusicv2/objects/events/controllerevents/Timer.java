package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class Timer {
    public long time;

    public Timer(long time) {
        this.time = time;
    }
}
