package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class MoveQueueItem {
    public int from;
    public int to;

    public MoveQueueItem(int from, int to) {
        this.from = from;
        this.to = to;
    }
}
