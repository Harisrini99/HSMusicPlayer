package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class Preset {
    public int preset;

    public Preset(int preset) {
        this.preset = preset;
    }
}
