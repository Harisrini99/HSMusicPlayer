package music.symphony.com.materialmusicv2.objects.events;

public class ShuffleState {
    public boolean state;

    public ShuffleState(boolean state) {
        this.state = state;
    }
}
