package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class BassBoostLevel {

    public int level;

    public BassBoostLevel(int level) {
        this.level = level;
    }
}
