package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class PlaySongAtStart {
    public String path;

    public PlaySongAtStart(String path) {
        this.path = path;
    }
}
