package music.symphony.com.materialmusicv2.utils.fileutils;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}