package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class SeekTo {
    public int position;

    public SeekTo(int position) {
        this.position = position;
    }
}
