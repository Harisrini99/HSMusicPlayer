package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class Reverb {
    public int reverb;

    public Reverb(int reverb) {
        this.reverb = reverb;
    }
}
