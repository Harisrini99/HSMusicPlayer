package music.symphony.com.materialmusicv2.utils.gaplessfadingmediaplayer.fadingmediaplayer;

public interface FadeMethods {
}
