package music.symphony.com.materialmusicv2.objects.events;

public class RepeatState {
    public int state;

    public RepeatState(int state) {
        this.state = state;
    }
}
