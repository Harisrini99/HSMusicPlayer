package music.symphony.com.materialmusicv2.objects.events;

public class SongPositionInQueue {
    public int position;

    public SongPositionInQueue(int position) {
        this.position = position;
    }
}
