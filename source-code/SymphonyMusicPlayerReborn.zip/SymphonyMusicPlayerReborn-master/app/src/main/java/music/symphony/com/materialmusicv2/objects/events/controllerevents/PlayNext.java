package music.symphony.com.materialmusicv2.objects.events.controllerevents;

public class PlayNext {
}
